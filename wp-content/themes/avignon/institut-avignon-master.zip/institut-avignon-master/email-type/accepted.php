<?php ?>
<tr width="600">
    <td width="600" valign="top">
        <table cellpadding="0" cellspacing="0" border="0" align="center" width="600" style="table-layout: fixed;">
            <tr width="600">
                <td width="30" valign="top"><img class="image_fix" src="img/empty.gif" alt=" " width="30" border="0" style="border:0;"></td>
                <td width="540" valign="top">
                    <table cellpadding="0" cellspacing="0" border="0" align="center" width="540" style="table-layout: fixed;">
                        <!-- Titre / Sous-titre -->
                        <tr width="540" height="40">
                            <td width="540" height="40" valign="top" style="background-color: #ffffff;"><img class="image_fix" src="img/empty.gif" alt=" " width="540" height="40" border="0" style="border:0;"></td>
                        </tr>
                        <tr width="540">
                            <td width="540" valign="top" style="font-family: Georgia, Times, 'Times New Roman', serif; font-weight: bold; font-size: 23px; text-align: center;">
                                <h1 style="font-family: Georgia, Times, 'Times New Roman', serif; font-weight: bold; font-size: 23px; text-align: center; margin: 8px 0;">Congratulations!</h1>
                            </td>
                        </tr>
                        <tr width="540" height="5">
                            <td width="540" height="5" valign="top" style="background-color: #ffffff;"><img class="image_fix" src="img/empty.gif" alt=" " width="540" height="5" border="0" style="border:0;"></td>
                        </tr>
                        <tr width="540" height="1">
                            <td width="540" height="1" valign="top">
                                <table cellpadding="0" cellspacing="0" border="0" align="center" width="540" height="1" style="table-layout: fixed;">
                                    <tr width="540" height="1">
                                        <td width="50" height="1" valign="top" style="background-color: #ffffff;"><img class="image_fix" src="img/empty.gif" alt=" " width="50" height="1" border="0" style="border:0;"></td>
                                        <td width="440" height="1" valign="top" style="background-color: #d5d9da;"><img class="image_fix" src="img/empty.gif" alt=" " width="440" height="1" border="0" style="border:0;"></td>
                                        <td width="50" height="1" valign="top" style="background-color: #ffffff;"><img class="image_fix" src="img/empty.gif" alt=" " width="50" height="1" border="0" style="border:0;"></td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr width="540">
                            <td width="540" valign="top" style="font-family: Georgia, Times, 'Times New Roman', serif; font-weight: normal; font-size: 18px; text-align: center;">
                                <h2 style="font-family: Georgia, Times, 'Times New Roman', serif; font-weight: normal; font-size: 18px; text-align: center; margin: 8px 0;">Your application was accepted</h2>
                            </td>
                        </tr>
                        <!-- Fin titre / Sous-titre -->
                        <!-- Séparateur -->
                        <tr width="540" height="20">
                            <td width="540" height="20" valign="top" style="background-color: #ffffff;"><img class="image_fix" src="img/empty.gif" alt=" " width="540" height="20" border="0" style="border:0;"></td>
                        </tr>
                        <tr width="540" height="13">
                            <td width="540" height="13" valign="top">
                                <table cellpadding="0" cellspacing="0" border="0" align="center" width="540" height="13" style="table-layout: fixed;">
                                    <tr width="540" height="13">
                                        <td width="227" height="13" valign="top" style="background-color: #ffffff;"><img class="image_fix" src="img/empty.gif" alt=" " width="227" height="13" border="0" style="border:0;"></td>
                                        <td width="85" height="13" valign="top" style="background-color: #ffffff;"><img class="image_fix" src="img/separateur.gif" alt=" " width="85" height="13" border="0" style="border:0;"></td>
                                        <td width="228" height="13" valign="top" style="background-color: #ffffff;"><img class="image_fix" src="img/empty.gif" alt=" " width="228" height="13" border="0" style="border:0;"></td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr width="540" height="20">
                            <td width="540" height="20" valign="top" style="background-color: #ffffff;"><img class="image_fix" src="img/empty.gif" alt=" " width="540" height="20" border="0" style="border:0;"></td>
                        </tr>
                        <!-- Fin séparateur -->
                        <tr width="540">
                            <td width="540" valign="top" style="background-color: #ffffff;">
                                <h3 style="font-family: TimesNewRoman, 'Times New Roman', Times, Baskerville, Georgia, serif; font-weight: bold; font-size: 18px; text-align: center;">Health evaluation</h3>
                                <p style="font-family: TimesNewRoman, 'Times New Roman', Times, Baskerville, Georgia, serif; font-weight: normal; font-size: 14px; line-height: 16px;">You still need to provide us with a signed health evaluation for you to be officially enrolled in the program.</p>
                                <p style="font-family: TimesNewRoman, 'Times New Roman', Times, Baskerville, Georgia, serif; font-weight: normal; font-size: 14px; line-height: 16px;">Here is the health evaluation form to be completed by you and your doctor:</p>
                            </td>
                            <td width="540" valign="top" style="font-family: Georgia, Times, 'Times New Roman', serif; font-weight: bold; font-size: 14px; text-align: center; color: #942814; text-decoration: none;">
                                <a href="<?php the_field( 'health_evaluation_file', 'options' ) ?>" style="font-family: Georgia, Times, 'Times New Roman', serif; font-weight: bold; font-size: 14px; text-align: center; color: #942814; text-decoration: none;"><?php the_field( 'health_evaluation_file', 'options' ) ?></a>
                            </td>
                        </tr>
                        <tr width="540">
                            <td width="540" valign="top" style="background-color: #ffffff;">
                               <p style="font-family: TimesNewRoman, 'Times New Roman', Times, Baskerville, Georgia, serif; font-weight: normal; font-size: 14px; line-height: 16px;">Once completed this document , you can send it to us via the form provided here :</p>
                            </td>
                            <td width="540" valign="top" style="font-family: Georgia, Times, 'Times New Roman', serif; font-weight: bold; font-size: 14px; text-align: center; color: #942814; text-decoration: none;">
                                <a href="<?php echo add_query_arg( 'token', $token, get_permalink( AVIGNON_HEALTH_EVALUATION_PAGE_ID ) ) ?>" style="font-family: Georgia, Times, 'Times New Roman', serif; font-weight: bold; font-size: 14px; text-align: center; color: #942814; text-decoration: none;"><?php echo add_query_arg( 'token', $token, get_permalink( AVIGNON_HEALTH_EVALUATION_PAGE_ID ) ) ?></a>
                            </td>
                        </tr>
                        <!-- Séparateur -->
                        <tr width="540" height="20">
                            <td width="540" height="20" valign="top" style="background-color: #ffffff;"><img class="image_fix" src="img/empty.gif" alt=" " width="540" height="20" border="0" style="border:0;"></td>
                        </tr>
                        <tr width="540" height="13">
                            <td width="540" height="13" valign="top">
                                <table cellpadding="0" cellspacing="0" border="0" align="center" width="540" height="13" style="table-layout: fixed;">
                                    <tr width="540" height="13">
                                        <td width="227" height="13" valign="top" style="background-color: #ffffff;"><img class="image_fix" src="img/empty.gif" alt=" " width="227" height="13" border="0" style="border:0;"></td>
                                        <td width="85" height="13" valign="top" style="background-color: #ffffff;"><img class="image_fix" src="img/separateur.gif" alt=" " width="85" height="13" border="0" style="border:0;"></td>
                                        <td width="228" height="13" valign="top" style="background-color: #ffffff;"><img class="image_fix" src="img/empty.gif" alt=" " width="228" height="13" border="0" style="border:0;"></td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr width="540" height="20">
                            <td width="540" height="20" valign="top" style="background-color: #ffffff;"><img class="image_fix" src="img/empty.gif" alt=" " width="540" height="20" border="0" style="border:0;"></td>
                        </tr>
                        <!-- Fin séparateur -->
                        <tr width="540">
                            <td width="540" valign="top" style="background-color: #ffffff;">
                                <h3 style="font-family: TimesNewRoman, 'Times New Roman', Times, Baskerville, Georgia, serif; font-weight: bold; font-size: 18px; text-align: center;">Information for admitted students</h3>
                                <p style="font-family: TimesNewRoman, 'Times New Roman', Times, Baskerville, Georgia, serif; font-weight: normal; font-size: 14px; line-height: 16px;">Here are some helpful tips on the best way to prepare for your trip to France:</p>
                            </td>
                            <td width="540" valign="top" style="font-family: Georgia, Times, 'Times New Roman', serif; font-weight: bold; font-size: 14px; text-align: center; color: #942814; text-decoration: none;">
                                <a href="<?php echo get_permalink( AVIGNON_INFORMATIONS_PAGE_ID ) ?>" style="font-family: Georgia, Times, 'Times New Roman', serif; font-weight: bold; font-size: 14px; text-align: center; color: #000000; text-decoration: none;"><?php echo get_permalink( AVIGNON_INFORMATIONS_PAGE_ID ) ?></a>
                            </td>
                        </tr>
                        <!-- Séparateur -->
                        <tr width="540" height="20">
                            <td width="540" height="20" valign="top" style="background-color: #ffffff;"><img class="image_fix" src="img/empty.gif" alt=" " width="540" height="20" border="0" style="border:0;"></td>
                        </tr>
                        <tr width="540" height="13">
                            <td width="540" height="13" valign="top">
                                <table cellpadding="0" cellspacing="0" border="0" align="center" width="540" height="13" style="table-layout: fixed;">
                                    <tr width="540" height="13">
                                        <td width="227" height="13" valign="top" style="background-color: #ffffff;"><img class="image_fix" src="img/empty.gif" alt=" " width="227" height="13" border="0" style="border:0;"></td>
                                        <td width="85" height="13" valign="top" style="background-color: #ffffff;"><img class="image_fix" src="img/separateur.gif" alt=" " width="85" height="13" border="0" style="border:0;"></td>
                                        <td width="228" height="13" valign="top" style="background-color: #ffffff;"><img class="image_fix" src="img/empty.gif" alt=" " width="228" height="13" border="0" style="border:0;"></td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr width="540" height="20">
                            <td width="540" height="20" valign="top" style="background-color: #ffffff;"><img class="image_fix" src="img/empty.gif" alt=" " width="540" height="20" border="0" style="border:0;"></td>
                        </tr>
                        <!-- Fin séparateur -->
                        <tr width="540">
                            <td width="540" valign="top" style="background-color: #ffffff;">
                                <h3 style="font-family: TimesNewRoman, 'Times New Roman', Times, Baskerville, Georgia, serif; font-weight: bold; font-size: 18px; text-align: center;">Housing</h3>
                                <p style="font-family: TimesNewRoman, 'Times New Roman', Times, Baskerville, Georgia, serif; font-weight: normal; font-size: 14px; line-height: 16px;">Please complete the housing form ASAP. Some options have limited availability and students’ preferences are handled on a first come first served basis:</p>
                            </td>
                            <td width="540" valign="top" style="font-family: Georgia, Times, 'Times New Roman', serif; font-weight: bold; font-size: 14px; text-align: center; color: #942814; text-decoration: none;">
                                <a href="<?php echo get_permalink( AVIGNON_HOUSING_PAGE_ID ) ?>" style="font-family: Georgia, Times, 'Times New Roman', serif; font-weight: bold; font-size: 14px; text-align: center; color: #000000; text-decoration: none;"><?php echo get_permalink( AVIGNON_HOUSING_PAGE_ID ) ?></a>
                            </td>
                        </tr>